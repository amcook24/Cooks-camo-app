import React from 'react';
import { View, Text, Pressable, ViewStyle, TextStyle } from 'react-native';
import { colors } from '../lib/theme';

export function Screen({ children }: { children: React.ReactNode }) {
  return <View style={{ flex: 1, backgroundColor: colors.bg, paddingHorizontal: 18, paddingTop: 58 }}>{children}</View>;
}
export function Eyebrow({ children }: { children: React.ReactNode }) {
  return <Text style={{ color: colors.orange, fontSize: 11, letterSpacing: 2, fontWeight: '900', marginBottom: 7 }}>{children}</Text>;
}
export function Heading({ children, style }: { children: React.ReactNode; style?: TextStyle }) {
  return <Text style={[{ color: colors.text, fontSize: 29, lineHeight: 34, fontWeight: '900', marginBottom: 8 }, style]}>{children}</Text>;
}
export function Body({ children, style }: { children: React.ReactNode; style?: TextStyle }) {
  return <Text style={[{ color: colors.muted, fontSize: 14, lineHeight: 21 }, style]}>{children}</Text>;
}
export function Panel({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  return <View style={[{ backgroundColor: colors.panel, borderColor: colors.line, borderWidth: 1, borderRadius: 16, padding: 16, marginBottom: 12 }, style]}>{children}</View>;
}
export function Action({ title, onPress, secondary=false }: { title: string; onPress?: () => void; secondary?: boolean }) {
  return <Pressable onPress={onPress} style={{ backgroundColor: secondary ? colors.panel2 : colors.orange, paddingVertical: 14, paddingHorizontal: 18, borderRadius: 12, alignItems: 'center', borderWidth: secondary ? 1 : 0, borderColor: colors.line }}>
    <Text style={{ color: colors.text, fontWeight: '900', letterSpacing: .5 }}>{title}</Text>
  </Pressable>;
}
export function Tag({ children }: { children: React.ReactNode }) {
  return <View style={{ backgroundColor: '#303a2d', borderRadius: 30, paddingHorizontal: 10, paddingVertical: 6, alignSelf: 'flex-start' }}><Text style={{ color: colors.cream, fontSize: 10, fontWeight: '800', letterSpacing: 1 }}>{children}</Text></View>;
}
