import React, { useMemo, useState } from 'react';
import { Text, View, Pressable } from 'react-native';
import { Screen, Eyebrow, Heading, Body, Panel, Action, Tag } from '../components/UI';
import { colors } from '../lib/theme';

type Deer = { id: number; name: string; points: number; x: number; y: number; };
const initial: Deer[] = [
  { id: 1, name: 'Fork Horn', points: 40, x: 18, y: 22 },
  { id: 2, name: 'Eight Point', points: 85, x: 58, y: 43 },
  { id: 3, name: 'Old Buck', points: 150, x: 38, y: 68 }
];

export function GameScreen() {
  const [deer, setDeer] = useState(initial);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [message, setMessage] = useState('Tap a deer to identify your target.');
  const [wind, setWind] = useState('W');
  const target = useMemo(() => deer.find(d => d.id === selected), [deer, selected]);

  function moveDeer() {
    setDeer(old => old.map(d => ({ ...d, x: 8 + Math.floor(Math.random() * 72), y: 12 + Math.floor(Math.random() * 68) })));
    setSelected(null);
    setMessage('The deer moved. Scout again and pick your target.');
    setWind(['N','S','E','W'][Math.floor(Math.random()*4)]);
  }
  function takeShot() {
    if (!target) { setMessage('Select a deer first.'); return; }
    const hit = Math.random() > 0.35;
    if (hit) { setScore(s => s + target.points); setMessage(`Clean shot on ${target.name}. +${target.points} points.`); setDeer(old => old.filter(d => d.id !== target.id)); }
    else { setMessage(`You missed ${target.name}. The woods went quiet.`); }
    setSelected(null);
  }
  function reset() { setDeer(initial); setSelected(null); setScore(0); setMessage('New hunt. Pick your target.'); setWind('W'); }

  return <Screen>
    <Eyebrow>COOK'S CAMO ARCADE</Eyebrow><Heading>WHITETAIL RUN</Heading>
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 }}>
      <Tag>WIND {wind}</Tag><Tag>SCORE {score}</Tag><Tag>{deer.length} DEER LEFT</Tag>
    </View>
    <Panel style={{ padding: 0, height: 360, overflow: 'hidden', backgroundColor: '#273526' }}>
      <View style={{ position: 'absolute', top: 0, left: 0, right: 0, height: '100%', backgroundColor: '#33432e' }} />
      <View style={{ position: 'absolute', left: -30, top: 40, width: 170, height: 260, borderRadius: 90, backgroundColor: '#202d20' }} />
      <View style={{ position: 'absolute', right: -30, top: 70, width: 170, height: 270, borderRadius: 90, backgroundColor: '#1d291e' }} />
      <Text style={{ color: '#d9dfcb', position: 'absolute', top: 12, left: 14, fontSize: 10, letterSpacing: 2, fontWeight: '900' }}>OAK RIDGE · DAYBREAK</Text>
      {deer.map(d => <Pressable key={d.id} onPress={() => { setSelected(d.id); setMessage(`${d.name} · ${d.points} points. Check the wind before shooting.`); }} style={{ position: 'absolute', left: `${d.x}%`, top: `${d.y}%`, alignItems: 'center' }}>
        <Text style={{ fontSize: 38 }}>{selected === d.id ? '🦌' : '🦌'}</Text>
        <View style={{ backgroundColor: selected === d.id ? colors.orange : '#182017', paddingHorizontal: 7, paddingVertical: 3, borderRadius: 7 }}>
          <Text style={{ color: 'white', fontSize: 9, fontWeight: '900' }}>{selected === d.id ? 'TARGET' : 'DEER'}</Text>
        </View>
      </Pressable>)}
      {deer.length === 0 ? <View style={{ position: 'absolute', top: '42%', width: '100%', alignItems: 'center' }}><Text style={{ color: 'white', fontSize: 22, fontWeight: '900' }}>HUNT COMPLETE</Text></View> : null}
    </Panel>
    <Panel style={{ marginTop: 3 }}>
      <Text style={{ color: colors.text, fontWeight: '800' }}>{message}</Text>
      <Body style={{ marginTop: 5 }}>Choose carefully. A missed shot can move the whole herd.</Body>
      <View style={{ height: 13 }} />
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <View style={{ flex: 1 }}><Action title="TAKE SHOT" onPress={takeShot} /></View>
        <View style={{ flex: 1 }}><Action title="SCOUT / WAIT" secondary onPress={moveDeer} /></View>
      </View>
      <View style={{ height: 9 }} /><Action title="START NEW HUNT" secondary onPress={reset} />
    </Panel>
    <Body style={{ fontSize: 11, marginBottom: 20 }}>Arcade game only. No real firearms or hunting advice.</Body>
  </Screen>;
}
