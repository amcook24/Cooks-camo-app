import React from 'react';
import { ScrollView, View, Text } from 'react-native';
import { Screen, Eyebrow, Heading, Body, Panel, Action, Tag } from '../components/UI';
import { colors } from '../lib/theme';

export function HomeScreen({ navigation }: any) {
  return <Screen><ScrollView showsVerticalScrollIndicator={false}>
    <Eyebrow>COOK'S CAMO PRESENTS</Eyebrow>
    <Heading>HUNT MORE.{"\n"}BE OUT THERE.</Heading>
    <Body>Your hunting community, field tools, gear and a little friendly competition. All in one place.</Body>
    <View style={{ height: 20 }} />
    <Panel style={{ backgroundColor: '#293326', padding: 20 }}>
      <Tag>WELCOME TO THE FIELD</Tag>
      <Text style={{ color: colors.text, fontSize: 24, fontWeight: '900', marginTop: 13 }}>Built for the{"\n"}ones who live it.</Text>
      <Body style={{ marginTop: 8 }}>Gear up, keep your season organized, and share the moments worth remembering.</Body>
      <View style={{ height: 15 }} />
      <Action title="EXPLORE THE SHOP" onPress={() => navigation.navigate('Shop')} />
    </Panel>
    <Eyebrow>YOUR APP</Eyebrow>
    <Panel><Text style={{ color: colors.text, fontSize: 17, fontWeight: '800' }}>Hunting journal</Text><Body>Log sits, weather, sightings and harvests.</Body></Panel>
    <Panel><Text style={{ color: colors.text, fontSize: 17, fontWeight: '800' }}>The community</Text><Body>Share photos, stories and updates with hunters.</Body></Panel>
    <Panel><Text style={{ color: colors.text, fontSize: 17, fontWeight: '800' }}>Whitetail game</Text><Body>Take a break and play the first in-app hunting game.</Body></Panel>
    <View style={{ height: 18 }} />
  </ScrollView></Screen>;
}
