import React, { useState } from 'react';
import { ScrollView, Text, View, TextInput } from 'react-native';
import { Screen, Eyebrow, Heading, Body, Panel, Action } from '../components/UI';
import { colors } from '../lib/theme';

export function HuntScreen() {
  const [species, setSpecies] = useState('Whitetail');
  const [location, setLocation] = useState('');
  const [notes, setNotes] = useState('');
  const [logs, setLogs] = useState<string[]>([]);
  const field = { color: colors.text, borderWidth: 1, borderColor: colors.line, backgroundColor: colors.bg, borderRadius: 10, padding: 12, marginTop: 8 };
  return <Screen><ScrollView showsVerticalScrollIndicator={false}>
    <Eyebrow>FIELD NOTES</Eyebrow><Heading>HUNT JOURNAL</Heading>
    <Body>Keep a record of the days that matter. This first build saves entries locally while account sync is being connected.</Body>
    <View style={{ height: 16 }} />
    <Panel>
      <Text style={{ color: colors.text, fontWeight: '900', fontSize: 17 }}>New entry</Text>
      <Text style={{ color: colors.muted, marginTop: 12 }}>Species</Text>
      <TextInput value={species} onChangeText={setSpecies} style={field} placeholderTextColor={colors.muted} />
      <Text style={{ color: colors.muted, marginTop: 12 }}>Property / location</Text>
      <TextInput value={location} onChangeText={setLocation} style={field} placeholder="Where did you hunt?" placeholderTextColor={colors.muted} />
      <Text style={{ color: colors.muted, marginTop: 12 }}>Notes</Text>
      <TextInput value={notes} onChangeText={setNotes} multiline style={[field, { minHeight: 90, textAlignVertical: 'top' }]} placeholder="Wind, weather, sightings, activity..." placeholderTextColor={colors.muted} />
      <View style={{ height: 14 }} />
      <Action title="SAVE JOURNAL ENTRY" onPress={() => { if (location.trim() || notes.trim()) { setLogs([`${species} · ${location || 'Location not set'} · ${notes || 'No notes'}`, ...logs]); setNotes(''); } }} />
    </Panel>
    <Text style={{ color: colors.text, fontWeight: '900', fontSize: 17, marginBottom: 10 }}>RECENT ENTRIES</Text>
    {logs.length ? logs.map((l, i) => <Panel key={i}><Body>{l}</Body></Panel>) : <Panel><Body>Your journal entries will show here.</Body></Panel>}
  </ScrollView></Screen>;
}
