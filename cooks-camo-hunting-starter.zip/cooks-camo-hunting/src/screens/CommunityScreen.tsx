import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { Screen, Eyebrow, Heading, Body, Panel, Action, Tag } from '../components/UI';
import { colors } from '../lib/theme';

export function CommunityScreen() {
  return <Screen><ScrollView showsVerticalScrollIndicator={false}>
    <Eyebrow>HUNTERS. STORIES. COMMUNITY.</Eyebrow><Heading>THE CAMP</Heading>
    <Body>A place for the hunting community to share the season.</Body>
    <View style={{ height: 15 }} />
    <Panel><Tag>COMMUNITY FEED</Tag><Text style={{ color: colors.text, fontWeight: '900', fontSize: 19, marginTop: 12 }}>Your people are out there.</Text><Body style={{ marginTop: 6 }}>Post harvest photos, trail-cam finds, scouting notes and stories from the field.</Body><View style={{ height: 14 }} /><Action title="COMMUNITY COMING ONLINE" secondary /></Panel>
    <Panel><Text style={{ color: colors.text, fontWeight: '800', fontSize: 16 }}>State-by-state hunting</Text><Body>Find hunters, follow local conversations and share what is happening in your part of the country.</Body></Panel>
    <Panel><Text style={{ color: colors.text, fontWeight: '800', fontSize: 16 }}>Youth hunting</Text><Body>Highlight opportunities and support the next generation of hunters.</Body></Panel>
  </ScrollView></Screen>;
}
