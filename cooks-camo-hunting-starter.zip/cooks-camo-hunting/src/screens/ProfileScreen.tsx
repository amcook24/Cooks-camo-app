import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { Screen, Eyebrow, Heading, Body, Panel, Tag } from '../components/UI';
import { colors } from '../lib/theme';

export function ProfileScreen() {
  return <Screen><ScrollView showsVerticalScrollIndicator={false}>
    <Eyebrow>YOUR ACCOUNT</Eyebrow><Heading>HUNTER PROFILE</Heading>
    <Panel style={{ alignItems: 'center', paddingVertical: 25 }}>
      <View style={{ width: 78, height: 78, borderRadius: 39, backgroundColor: colors.panel2, alignItems: 'center', justifyContent: 'center' }}><Text style={{ fontSize: 35 }}>🦌</Text></View>
      <Text style={{ color: colors.text, fontWeight: '900', fontSize: 20, marginTop: 12 }}>Your hunting profile</Text>
      <Body>Sign-in and cloud profile sync will be enabled in the next integration step.</Body>
    </Panel>
    <Panel><Tag>OPTIONAL MEMBERSHIP</Tag><Text style={{ color: colors.text, fontSize: 19, fontWeight: '900', marginTop: 10 }}>COOK'S CAMO+</Text><Body style={{ marginTop: 5 }}>An optional premium tier for advanced journal features, saved properties and deeper season stats. Core community access stays free.</Body></Panel>
    <Panel><Text style={{ color: colors.text, fontWeight: '800' }}>Settings & privacy</Text><Body>Account controls, privacy settings, notification preferences and support.</Body></Panel>
  </ScrollView></Screen>;
}
