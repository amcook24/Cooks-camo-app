export const colors = {
  bg: '#10130f',
  panel: '#1b211a',
  panel2: '#252d23',
  line: '#394335',
  text: '#f2f1e9',
  muted: '#a6ad9e',
  orange: '#e47b2d',
  green: '#82936c',
  cream: '#d7d2bd',
  red: '#c65c48'
};
