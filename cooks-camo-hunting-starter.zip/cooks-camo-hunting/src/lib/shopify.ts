export type Product = { id: string; title: string; price: string; image?: string; url: string };
const domain = process.env.EXPO_PUBLIC_SHOPIFY_STORE_DOMAIN;
const token = process.env.EXPO_PUBLIC_SHOPIFY_STOREFRONT_TOKEN;
const version = process.env.EXPO_PUBLIC_SHOPIFY_API_VERSION || '2026-10';

export async function fetchProducts(): Promise<Product[]> {
  if (!domain || !token) throw new Error('Shopify Storefront API credentials are not configured yet.');
  const query = `query Products { products(first: 30) { edges { node { id title handle onlineStoreUrl featuredImage { url altText } priceRange { minVariantPrice { amount currencyCode } } } } } }`;
  const response = await fetch(`https://${domain}/api/${version}/graphql.json`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Shopify-Storefront-Access-Token': token },
    body: JSON.stringify({ query })
  });
  if (!response.ok) throw new Error(`Shopify returned HTTP ${response.status}.`);
  const json = await response.json();
  if (json.errors?.length) throw new Error(json.errors[0].message || 'Shopify query failed.');
  return (json.data?.products?.edges || []).map(({ node }: any) => ({
    id: node.id,
    title: node.title,
    price: new Intl.NumberFormat('en-US', { style: 'currency', currency: node.priceRange.minVariantPrice.currencyCode }).format(Number(node.priceRange.minVariantPrice.amount)),
    image: node.featuredImage?.url,
    url: node.onlineStoreUrl || `https://${domain}/products/${node.handle}`
  }));
}
