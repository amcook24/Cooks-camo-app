# Cook's Camo: Hunting — app foundation

A React Native / Expo starter for a shared iOS + Android app.

## Included in this first build
- Branded six-tab navigation: Home, Shop, Community, Hunt, Game, Profile
- Dark outdoors-inspired UI foundation
- Playable Whitetail Run mini-game (tap deer, scout, shoot, score, restart)
- Hunt journal entry interaction (currently local component state)
- Shopify Storefront API product loader (requires a public Storefront token)
- Supabase schema starter for profiles, posts, likes, comments and hunting journal

## Important status
This is a runnable development foundation, **not an App Store-ready production release**.
Community posting, authentication, cloud journal sync, checkout/cart, push notifications,
subscriptions, moderation, analytics, mapping, weather and production security still need
implementation and testing. The mini-game uses emoji placeholders and random hit simulation;
it needs original artwork, animation, balancing and persistent leaderboards.

## Run locally
1. Install Node.js LTS and a package manager.
2. Copy `.env.example` to `.env` and fill in the public Shopify Storefront token.
3. Run `npm install`.
4. Run `npx expo start`.
5. Scan the QR code with Expo Go on your iPhone, or use an iOS/Android simulator.

## Shopify
The connected Shopify Admin catalog is the source of truth. The mobile app must use a
**Storefront API public token**, not an Admin API token. The current connected shop domain is
`5patm2-n2.myshopify.com`; the intended brand domain is `www.cookscamo.com`.
The product screen queries Shopify live at runtime. Checkout/cart and customer account
flows are not yet implemented.

Create/configure Storefront API access in Shopify, expose only the public Storefront token
to the client, and keep all Admin credentials server-side. Verify the API version against
Shopify's current supported versions before release.

## Supabase
1. Create a Supabase project.
2. Review and apply `supabase/schema.sql`.
3. Add the project URL and anon key to `.env`.
4. Implement auth/session handling and moderation before opening community posting to users.

## Next production milestones
1. Storefront token + cart and Shopify checkout
2. Supabase auth, profile setup and cloud-synced hunt journal
3. Community feed, image storage, reporting/blocking and moderation tools
4. Hunt tools: saved properties/stands, GPS permissions, weather/wind provider
5. Original game art, animation, game progression and server-validated leaderboards
6. Cook's Camo+ entitlements with Apple/Google in-app purchase compliance
7. Accessibility, privacy disclosures, security review, device QA and store submission
