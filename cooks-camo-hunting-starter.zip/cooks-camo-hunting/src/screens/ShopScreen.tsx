import React, { useEffect, useState } from 'react';
import { ScrollView, View, Text, Image, ActivityIndicator, Linking } from 'react-native';
import { Screen, Eyebrow, Heading, Body, Panel, Action } from '../components/UI';
import { colors } from '../lib/theme';
import { fetchProducts, Product } from '../lib/shopify';

export function ShopScreen() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  useEffect(() => { fetchProducts().then(setProducts).catch(e => setError(e.message)).finally(() => setLoading(false)); }, []);
  return <Screen><ScrollView showsVerticalScrollIndicator={false}>
    <Eyebrow>OFFICIAL COOK'S CAMO STORE</Eyebrow><Heading>THE SHOP</Heading>
    <Body>Gear and goods from Cook's Camo. Product availability and checkout are handled by Shopify.</Body>
    <View style={{ height: 16 }} />
    {loading ? <ActivityIndicator color={colors.orange} /> : error ? <Panel><Text style={{ color: colors.text, fontWeight: '800' }}>Store connection needs setup</Text><Body style={{ marginTop: 6 }}>{error}</Body><Body style={{ marginTop: 8 }}>Add the public Shopify Storefront API token to your local .env file. Never use an Admin API token in this app.</Body></Panel> :
      products.map(p => <Panel key={p.id} style={{ padding: 0, overflow: 'hidden' }}>
        {p.image ? <Image source={{ uri: p.image }} style={{ width: '100%', height: 190, backgroundColor: colors.panel2 }} resizeMode="cover" /> : null}
        <View style={{ padding: 15 }}>
          <Text style={{ color: colors.text, fontWeight: '900', fontSize: 17 }}>{p.title}</Text>
          <Text style={{ color: colors.orange, fontWeight: '900', fontSize: 16, marginTop: 6 }}>{p.price}</Text>
          <View style={{ height: 12 }} />
          <Action title="VIEW PRODUCT" onPress={() => Linking.openURL(p.url)} />
        </View>
      </Panel>)
    }
    <View style={{ height: 20 }} />
  </ScrollView></Screen>;
}
